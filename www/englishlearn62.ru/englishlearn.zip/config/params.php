<?php

return [
    'adminEmail' => 'admin@example.com',
    'senderEmail' => 'noreply@example.com',
    'senderName' => 'Example.com mailer',
    'subtitle' => 'Московский университет им. С.Ю. Витте',
    'btn-form-color' => 'primary',
    'bg-form-color' => 'light',
    'btn-form-color-admin' => 'danger',
    'bg-form-color-admin' => 'secondary',
];
