<div class="row mt-4">
    <div class="col-12 col-lg-7 mx-auto">
        <p class="text-center fs-4 font-monospace text-danger">
            <?=$h1?>
        </p>
    </div>
</div>