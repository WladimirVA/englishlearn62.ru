<footer class="mt-auto py-3 bg-light">
    <div class="container">
        <div class="row text-muted">
            <div class="col-md-6 text-center text-md-start">&copy; <?=Yii::$app -> name?> - <?=date('Y')?></div>
        </div>
    </div>
</footer>