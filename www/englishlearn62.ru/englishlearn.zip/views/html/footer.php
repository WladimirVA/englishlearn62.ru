<footer class="mt-auto py-3 bg-light">
    <div class="container">
        <div class="row text-muted">
            <div class="col-12 col-md-4 text-center text-md-start">&copy; <?= Yii::$app->name ?> - <?= date('Y') ?></div>
            <div class="col-12 col-md-8 text-end">
                <div class="vstack gap-1">
                    <div class="">
                        <a href="https://www.muiv.ru">Университет</a>
                    </div>
                    <div class="">
                        <a href="https://www.muiv.ru/studentu/">Студенту</a>
                    </div>
                    <div class="">
                        <a href="https://www.muiv.ru/studentu/graduates/">Выпускникам</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>