<?php

function du($o, $exit = 1){
    echo "<pre>" . print_r($o, true) . "</pre>";
    if($exit === 1) exit();
}







